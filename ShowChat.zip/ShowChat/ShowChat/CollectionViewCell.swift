//
//  CollectionViewCell.swift
//  ShowChat
//
//  Created by Fox (legal name:  Nick Borer) on 11/24/23.
//

import Foundation
import UIKit

class CollectionViewCell: UICollectionViewCell, UICollectionViewDelegate
{
   @IBOutlet weak var imageView: UIImageView!
   
   
}


