   //
   //  CollectionViewCell.swift
   //  ShowChat
   //
   //  Created by Fox (legal name:  Nick Borer) on 11/23/2023.
   //

import Foundation
import UIKit

class CommenterViewCell: UICollectionViewCell, UICollectionViewDelegate
{
   @IBOutlet weak var commenterImageView: UIImageView!
   
   
}


